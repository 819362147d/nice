//
//  LocationKeepAlive.swift
//  pip_swift
//
//  【社区补丁 2026-10-11】极限保活之定位保活（用户要求"全上"）
//  iOS 原生机制：UIBackgroundModes += location，拿到始终允许授权后系统持续给 App 定位更新。
//  代价：状态栏定位箭头常驻；精度用 3 公里档尽量省电，但仍有额外耗电；
//  用户必须在弹窗里选始终允许，只选使用期间允许则后台保活不生效。
//

import CoreLocation
import UIKit

final class LocationKeepAlive: NSObject {
    static let shared = LocationKeepAlive()

    private let manager = CLLocationManager()
    private var started = false

    private override init() {
        super.init()
        manager.delegate = self
        manager.desiredAccuracy = kCLLocationAccuracyThreeKilometers
        manager.distanceFilter = kCLDistanceFilterNone
        // 关键：不允许系统自动暂停位置更新，否则保活就断了
        manager.pausesLocationUpdatesAutomatically = false
        manager.allowsBackgroundLocationUpdates = true
    }

    /// App 启动时调用一次：触发始终允许授权弹窗（系统只弹一次）
    func ensurePermission() {
        if manager.authorizationStatus == .notDetermined {
            manager.requestAlwaysAuthorization()
        }
    }

    /// 进入后台时调用
    func start() {
        let status = manager.authorizationStatus
        guard status == .authorizedAlways else {
            if status == .notDetermined {
                manager.requestAlwaysAuthorization()
            } else {
                AppDebugLogger.log("定位保活未启动：需要始终允许定位授权")
            }
            return
        }
        if !started {
            started = true
            manager.startUpdatingLocation()
            AppDebugLogger.log("定位保活启动（精度3km，后台常驻）")
        }
    }

    /// 回到前台时调用（前台不需要定位保活，省电）
    func stop() {
        if started {
            started = false
            manager.stopUpdatingLocation()
            AppDebugLogger.log("定位保活停止（回到前台）")
        }
    }
}

extension LocationKeepAlive: CLLocationManagerDelegate {
    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        if manager.authorizationStatus == .authorizedAlways,
           UIApplication.shared.applicationState != .active {
            LocationKeepAlive.shared.start()
        }
    }

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        // 保活不需要处理位置本身，只要系统持续回调，App 就不会被挂起
    }

    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        AppDebugLogger.log("定位保活错误")
    }
}
