//
//  SceneDelegate.swift
//  pip_swift
//
//  Created by 无夜之星辰 on 2021/5/26.
//

import UIKit

class SceneDelegate: UIResponder, UIWindowSceneDelegate {

    var window: UIWindow?


    func scene(_ scene: UIScene, willConnectTo session: UISceneSession, options connectionOptions: UIScene.ConnectionOptions) {
        guard let windowScene = scene as? UIWindowScene else { return }

        let window = UIWindow(windowScene: windowScene)
        window.rootViewController = MainTabBarController()
        AppAppearancePreference.apply(to: window)
        self.window = window
        window.makeKeyAndVisible()

        handleShortcutURLContexts(connectionOptions.urlContexts)
    }

    func sceneDidDisconnect(_ scene: UIScene) {
        // Called as the scene is being released by the system.
        // This occurs shortly after the scene enters the background, or when its session is discarded.
        // Release any resources associated with this scene that can be re-created the next time the scene connects.
        // The scene may re-connect later, as its session was not necessarily discarded (see `application:didDiscardSceneSessions` instead).
    }

    func sceneDidBecomeActive(_ scene: UIScene) {
        print("sceneDidBecomeActive")
        // 【社区补丁 2026-10-11】回到前台，释放后台任务链
        BackgroundTaskChain.shared.stop()
        LocationKeepAlive.shared.stop()
    }

    func sceneDidEnterBackground(_ scene: UIScene) {
        print("sceneDidEnterBackground")
        // 【社区补丁 2026-10-11】极限保活：进入后台启动后台任务链
        //（静音音频仍是主力，本链覆盖音频未启用时的空窗）
        BackgroundTaskChain.shared.start()
        // 【社区补丁 2026-10-11】定位保活（需用户授权始终允许）
        LocationKeepAlive.shared.start()
    }

    func scene(_ scene: UIScene, openURLContexts URLContexts: Set<UIOpenURLContext>) {
        handleShortcutURLContexts(URLContexts)
    }

    private func handleShortcutURLContexts(_ URLContexts: Set<UIOpenURLContext>) {
        for context in URLContexts {
            if PiPShortcutActionCenter.request(from: context.url) {
                (window?.rootViewController as? MainTabBarController)?
                    .handleExternalShortcutRequest(reason: "URL快捷指令")
                break
            }
        }
    }

}
